![](https://git.icviet.com/ci/projects/3/status.png?ref=master)
# APP SAMPLE STM8

# Config key
## Add thêm nút KONO cho bộ điều khiển.
+ Nhấn và giữ nút SET trên vỏ hộp ( có lỗ nhỏ, dùng cây nhọn cắm vào) thời gian > 5s -> led báo sẽ sáng lên
+ Bấm nút KONO để add nút vào -> led sẽ nhấp nháy báo hiệu thành công
+ Reset lại nguồn

## 2. Xoá hết lệnh nút KONO cũ.
+ Nhấn và giữ nút SET trên vỏ hộp ( có lỗ nhỏ, dùng cây nhọn cắm vào) thời gian > 5s -> led báo sẽ sáng lên
+ Chờ sau 10s
+ Nhấn giữ tiếp nút SET -> led tắt báo hiệu đã xoá hết
