#include <stm8s.h>
#include "ws2812b.h"

//unsigned char LED_COLOR[Number_Leds][3];
uint8_t LedsArray[NB_LEDS * 3];
uint16_t nbLedsBytes = NB_LEDS * 3;
void WS2812_SendArray()
{
  disableInterrupts();
  __asm
  lb_intiLoop:
  LDW      X,             #0xFFFF       // set -1 in X, so that first inc gets 0, as inc has to be in the beginning of the loop
  LDW      Y,             _nbLedsBytes //2
  lb_begin_loop:
  //---------------------------------------------------------------
  //--------------- bit 0 -----------------------------------------
  INCW    X                           // L t+2
  lb_start_bit0:                      //
  LD      A,           (_LedsArray, X) //
  bset 0x5000, #3 // A3 high
  AND     A,             #0x80        // H t2
  JREQ    lb_bit0_Send_0            // H0 t3 t4 : 2 jump to Zero, 1 Stay in One + next nop
  lb_bit0_Send_1:                     //------Send 1 : 800ns High, 450ns Low (12,8) 750ns,500ns
  nop                                 // H1 t5
  nop                                 // H1 t6
  nop                                 // H1 t7
  nop                                 // H1 t8
  nop                                 // H1 t9
  nop                                 // H1 t10
  nop                                 // H1 t11
  nop                                 // H1 t12
  bres 0x5000, #3 // A3 low                         // L1 t1
  nop                                 // L1 t2
  JRA     lb_start_bit1             // L1 JRA:2 t4
  // L1 NextBitTest:4  t8
  lb_bit0_Send_0:                     //------Send 0 : 400ns High, 850ns Low (7,13) 375ns,875ns
  // H0 t4
  bres 0x5000, #3 // A3 low                         // L0 t1
  nop                                 // L0 t1
  nop                                 // L0 t2
  nop                                 // L0 t3
  nop                                 // L0 t4
  nop                                 // L0 t5
  nop                                 // L0 t6
  nop                                 // L0 t7
  nop                                 // L0 t8
  //NextBitTest:4+SP = 5. L t13
  //--------------- bit 1 -----------------------------------------
  lb_start_bit1:                      //
  LD      A,           (_LedsArray, X) //1
  AND     A,             #0x40        //1
  JREQ    lb_bit1_Send_0            //2 jump to Zero, 1 Stay in One + next nop
  lb_bit1_Send_1:
  nop                                 //1 to have send0 send1 equality
  bset 0x5000, #3 // A3 high                           // H t1
  nop                                 // H t2
  nop                                 // H t3
  nop                                 // H t4
  nop                                 // H t5
  nop                                 // H t6
  nop                                 // H t7
  nop                                 // H t8
  nop                                 // H t9
  nop                                 // H t10
  nop                                 // H t11
  nop                                 // H t12
  bres 0x5000, #3 // A3 low                         // L t1
  nop                                 // L t2
  JRA     lb_start_bit2             // L JRA:2 t4
  // L NextBitTest:4  t8
  lb_bit1_Send_0:                     //------Send 0 : 400ns High, 850ns Low (6,14) 375ns,875ns
  bset 0x5000, #3 // A3 high                           // H t1
  nop                                 // H t2
  nop                                 // H t3
  nop                                 // H t4
  nop                                 // H t5
  nop                                 // H t6
  bres 0x5000, #3 // A3 low                         // L t1
  nop                                 // L t1
  nop                                 // L t2
  nop                                 // L t3
  nop                                 // L t4
  nop                                 // L t5
  nop                                 // L t6
  nop                                 // L t7
  nop                                 // L t8
  nop                                 // L t9
  //NextBitTest:4+SP = 5. L t14
  //--------------- bit 2 -----------------------------------------
  lb_start_bit2:                      //
  LD      A,           (_LedsArray, X) //1
  AND     A,             #0x20        //1
  JREQ    lb_bit2_Send_0            //2 jump to Zero, 1 Stay in One + next nop
  lb_bit2_Send_1:
  nop                                 //1 to have send0 send1 equality
  bset 0x5000, #3 // A3 high                           // H t1
  nop                                 // H t2
  nop                                 // H t3
  nop                                 // H t4
  nop                                 // H t5
  nop                                 // H t6
  nop                                 // H t7
  nop                                 // H t8
  nop                                 // H t9
  nop                                 // H t10
  nop                                 // H t11
  nop                                 // H t12
  bres 0x5000, #3 // A3 low                         // L t1
  nop                                 // L t2
  JRA     lb_start_bit3             // L JRA:2 t4
  // L NextBitTest:4  t8
  lb_bit2_Send_0:                     //------Send 0 : 400ns High, 850ns Low (6,14) 375ns,875ns
  bset 0x5000, #3 // A3 high                           // H t1
  nop                                 // H t2
  nop                                 // H t3
  nop                                 // H t4
  nop                                 // H t5
  nop                                 // H t6
  bres 0x5000, #3 // A3 low                         // L t1
  nop                                 // L t1
  nop                                 // L t2
  nop                                 // L t3
  nop                                 // L t4
  nop                                 // L t5
  nop                                 // L t6
  nop                                 // L t7
  nop                                 // L t8
  nop                                 // L t9
  //NextBitTest:4+SP = 5. L t14
  //--------------- bit 3 -----------------------------------------
  lb_start_bit3:                      //
  LD      A,           (_LedsArray, X) //1
  AND     A,             #0x10        //1
  JREQ    lb_bit3_Send_0            //2 jump to Zero, 1 Stay in One + next nop
  lb_bit3_Send_1:
  nop                                 //1 to have send0 send1 equality
  bset 0x5000, #3 // A3 high                           // H t1
  nop                                 // H t2
  nop                                 // H t3
  nop                                 // H t4
  nop                                 // H t5
  nop                                 // H t6
  nop                                 // H t7
  nop                                 // H t8
  nop                                 // H t9
  nop                                 // H t10
  nop                                 // H t11
  nop                                 // H t12
  bres 0x5000, #3 // A3 low                         // L t1
  nop                                 // L t2
  JRA     lb_start_bit4             // L JRA:2 t4
  // L NextBitTest:4  t8
  lb_bit3_Send_0:                     //------Send 0 : 400ns High, 850ns Low (6,14) 375ns,875ns
  bset 0x5000, #3 // A3 high                           // H t1
  nop                                 // H t2
  nop                                 // H t3
  nop                                 // H t4
  nop                                 // H t5
  nop                                 // H t6
  bres 0x5000, #3 // A3 low                         // L t1
  nop                                 // L t1
  nop                                 // L t2
  nop                                 // L t3
  nop                                 // L t4
  nop                                 // L t5
  nop                                 // L t6
  nop                                 // L t7
  nop                                 // L t8
  nop                                 // L t9
  //NextBitTest:4+SP = 5. L t14
  //--------------- bit 4 -----------------------------------------
  lb_start_bit4:                      //
  LD      A,           (_LedsArray, X) //1
  AND     A,             #0x08        //1
  JREQ    lb_bit4_Send_0            //2 jump to Zero, 1 Stay in One + next nop
  lb_bit4_Send_1:
  nop                                 //1 to have send0 send1 equality
  bset 0x5000, #3 // A3 high                           // H t1
  nop                                 // H t2
  nop                                 // H t3
  nop                                 // H t4
  nop                                 // H t5
  nop                                 // H t6
  nop                                 // H t7
  nop                                 // H t8
  nop                                 // H t9
  nop                                 // H t10
  nop                                 // H t11
  nop                                 // H t12
  bres 0x5000, #3 // A3 low                         // L t1
  nop                                 // L t2
  JRA     lb_start_bit5             // L JRA:2 t4
  // L NextBitTest:4  t8
  lb_bit4_Send_0:                     //------Send 0 : 400ns High, 850ns Low (6,14) 375ns,875ns
  bset 0x5000, #3 // A3 high                           // H t1
  nop                                 // H t2
  nop                                 // H t3
  nop                                 // H t4
  nop                                 // H t5
  nop                                 // H t6
  bres 0x5000, #3 // A3 low                         // L t1
  nop                                 // L t1
  nop                                 // L t2
  nop                                 // L t3
  nop                                 // L t4
  nop                                 // L t5
  nop                                 // L t6
  nop                                 // L t7
  nop                                 // L t8
  nop                                 // L t9
  //NextBitTest:4+SP = 5. L t14
  //--------------- bit 5 -----------------------------------------
  lb_start_bit5:                      //
  LD      A,           (_LedsArray, X) //1
  AND     A,             #0x04        //1
  JREQ    lb_bit5_Send_0            //2 jump to Zero, 1 Stay in One + next nop
  lb_bit5_Send_1:
  nop                                 //1 to have send0 send1 equality
  bset 0x5000, #3 // A3 high                           // H t1
  nop                                 // H t2
  nop                                 // H t3
  nop                                 // H t4
  nop                                 // H t5
  nop                                 // H t6
  nop                                 // H t7
  nop                                 // H t8
  nop                                 // H t9
  nop                                 // H t10
  nop                                 // H t11
  nop                                 // H t12
  bres 0x5000, #3 // A3 low                         // L t1
  nop                                 // L t2
  JRA     lb_start_bit6             // L JRA:2 t4
  // L NextBitTest:4  t8
  lb_bit5_Send_0:                     //------Send 0 : 400ns High, 850ns Low (6,14) 375ns,875ns
  bset 0x5000, #3 // A3 high                           // H t1
  nop                                 // H t2
  nop                                 // H t3
  nop                                 // H t4
  nop                                 // H t5
  nop                                 // H t6
  bres 0x5000, #3 // A3 low                         // L t1
  nop                                 // L t1
  nop                                 // L t2
  nop                                 // L t3
  nop                                 // L t4
  nop                                 // L t5
  nop                                 // L t6
  nop                                 // L t7
  nop                                 // L t8
  nop                                 // L t9
  //NextBitTest:4+SP = 5. L t14
  //--------------- bit 6 -----------------------------------------
  lb_start_bit6:                      //
  LD      A,           (_LedsArray, X) //1
  AND     A,             #0x02        //1
  JREQ    lb_bit6_Send_0            //2 jump to Zero, 1 Stay in One + next nop
  lb_bit6_Send_1:
  nop                                 //1 to have send0 send1 equality
  bset 0x5000, #3 // A3 high                           // H t1
  nop                                 // H t2
  nop                                 // H t3
  nop                                 // H t4
  nop                                 // H t5
  nop                                 // H t6
  nop                                 // H t7
  nop                                 // H t8
  nop                                 // H t9
  nop                                 // H t10
  nop                                 // H t11
  nop                                 // H t12
  bres 0x5000, #3 // A3 low                         // L t1
  nop                                 // L t2
  JRA     lb_start_bit7             // L JRA:2 t4
  // L NextBitTest:4  t8
  lb_bit6_Send_0:                     //------Send 0 : 400ns High, 850ns Low (6,14) 375ns,875ns
  bset 0x5000, #3 // A3 high                           // H t1
  nop                                 // H t2
  nop                                 // H t3
  nop                                 // H t4
  nop                                 // H t5
  nop                                 // H t6
  bres 0x5000, #3 // A3 low                         // L t1
  nop                                 // L t1
  nop                                 // L t2
  nop                                 // L t3
  nop                                 // L t4
  nop                                 // L t5
  nop                                 // L t6
  nop                                 // L t7
  nop                                 // L t8
  nop                                 // L t9
  //NextBitTest:4+SP = 5. L t14
  //--------------- bit 7 -----------------------------------------
  lb_start_bit7:                      //
  LD      A,           (_LedsArray, X) //1
  AND     A,             #0x01        //1
  JREQ    lb_bit7_Send_0            //2 jump to Zero, 1 Stay in One + next nop
  lb_bit7_Send_1:
  nop                                 //1 to have send0 send1 equality
  bset 0x5000, #3 // A3 high                           // H t1
  nop                                 // H t2
  nop                                 // H t3
  nop                                 // H t4
  nop                                 // H t5
  nop                                 // H t6
  nop                                 // H t7
  nop                                 // H t8
  nop                                 // H t9
  nop                                 // H t10
  nop                                 // H t11
  nop                                 // H t12
  bres 0x5000, #3 // A3 low                         // L t1
  DECW    Y                           //2
  JREQ    lb_exit                   //1 on loop, 2 jmp to exit
  JP      lb_begin_loop             //5
  //
  lb_bit7_Send_0:                     //------Send 0 : 400ns High, 850ns Low (6,14) 375ns,875ns
  bset 0x5000, #3 // A3 high                           // H t1
  nop                                 // H t2
  nop                                 // H t3
  nop                                 // H t4
  nop                                 // H t5
  nop                                 // H t6
  bres 0x5000, #3 // A3 low                         // L t1
  nop                                 // L t1
  nop                                 // L t2
  nop                                 // L t3
  nop                                 // L t4
  nop                                 // L t5
  nop                                 // L t6
  // L DECW 2, JREQ 1, 2 = 5 =>   t14
  //--------------------------------------------------------
  //--------------------------------------------------------
  DECW    Y                           //2
  JREQ    lb_exit                   //1 on loop, 2 jmp to exit
  JP      lb_begin_loop             //5
  lb_exit:
  nop
  __endasm;
  enableInterrupts();
}

void WS2812_send_data(uint8_t ledId, uint32_t color)
{
  uint16_t ledAdd;
  ledAdd = (uint16_t)ledId*3;
  LedsArray[ledAdd] = (uint8_t)((color&0xFF00)>>8);
  LedsArray[ledAdd+1] = (uint8_t)((color&0xFF)>>0);
  LedsArray[ledAdd+2] = (uint8_t)((color&0xFF0000)>>16);
}

void WS2812_Reset()
{
  uint16_t i;
  for (i = 0; i < NB_LEDS ; i++)
  {
    WS2812_send_data(i, 0);
  }

}
