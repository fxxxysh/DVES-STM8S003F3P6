
#include "stm8s.h"


#define Number_Leds  240

////////////////////////////////////////
#define GPIOA_PORT    0x5000
#define GPIOB_PORT    0x5005
#define GPIOC_PORT    0x500A
#define GPIOD_PORT    0x500F
#define GPIOE_PORT    0x5014
#define GPIOF_PORT    0x5019
#define GPIOG_PORT    0x501E
#define GPIOH_PORT    0x5023
#define GPIOI_PORT    0x5028
////////////////////////////////////////

#define WS2812B_PORT  GPIOA_PORT
#define WS2812B_PIN   3

#define NB_LEDS       240

#define _ws2812b_create_port(__set__, __port__, __pin__) #__set__" L:"#__port__", #"#__pin__" \n"
#define ws2812b_create_port(__set__, __port__, __pin__) _ws2812b_create_port(__set__, __port__, __pin__)

#define RGBLedPin_Set   ws2812b_create_port(BSET, WS2812B_PORT, WS2812B_PIN)
#define RGBLedPin_ReSet ws2812b_create_port(BRES, WS2812B_PORT, WS2812B_PIN)

#define GUI_BLUE          0xFF0000
#define GUI_GREEN         0x00FF00
#define GUI_RED           0x0000FF
#define GUI_CYAN          0xFFFF00
#define GUI_MAGENTA       0xFF00FF
#define GUI_YELLOW        0x00FFFF
#define GUI_ORANGE		  0x0045FF
#define GUI_LIGHTBLUE     0xFF8080
#define GUI_LIGHTGREEN    0x80FF80
#define GUI_LIGHTRED      0x8080FF
#define GUI_LIGHTCYAN     0xFFFF80
#define GUI_LIGHTMAGENTA  0xFF80FF
#define GUI_LIGHTYELLOW   0x80FFFF
#define GUI_DARKBLUE      0x800000
#define GUI_DARKGREEN     0x008000
#define GUI_DARKRED       0x000080
#define GUI_DARKCYAN      0x808000
#define GUI_DARKMAGENTA   0x800080
#define GUI_DARKYELLOW    0x008080
#define GUI_WHITE         0xFFFFFF
#define GUI_LIGHTGRAY     0xD3D3D3
#define GUI_GRAY          0x808080
#define GUI_DARKGRAY      0x404040
#define GUI_BLACK         0x000000

#define GUI_BROWN         0x2A2AA5

void WS2812_SendArray(void);
void WS2812_send_data(uint8_t ledId, uint32_t color);
void WS2812_Reset();
