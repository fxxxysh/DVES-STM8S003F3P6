#ifndef _SYS_H_
#define _SYS_H_
 
#include "stm8s.h"
#include "timerTick.h"

typedef struct {
	TIME 		tick;
	uint8_t     encnt;
	uint8_t     lastencnt;
}SYS_STRUCT;

extern SYS_STRUCT sys;

void system_init(void);
void system_readEncoder(void);
void system_manager(void);
#endif
