#ifndef _LEDSTT_H_
#define _LEDSTT_H_

#include "stm8s.h"
#include "timerTick.h"

#define MAX_LED				8
#define PORT_LED 			GPIOD
#define PIN_LED 			GPIO_PIN_2

typedef enum{
	LED_OFF = 0,
	LED_ON,
	LED_FLASH
}LED_EVENT;

typedef struct{
	TIME tick;
	GPIO_TypeDef* port[MAX_LED];
	uint16_t pin[MAX_LED];
	uint8_t mode[MAX_LED];
	uint8_t cnt[MAX_LED];
	uint8_t timeOn[MAX_LED];
}LED_STR;

void ledstt_init(void);
uint8_t led_getstatus(void);
void led_change(uint8_t id, uint8_t mode, uint8_t time);

#endif