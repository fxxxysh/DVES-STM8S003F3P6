
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H
#include "stm8s.h"
#include "timerTick.h"

#define CTRA_GPIO       									GPIOC
#define CTRB_GPIO  											GPIOC
#define CTRA_PIN      	 									GPIO_PIN_3
#define CTRB_PIN  											GPIO_PIN_4

#endif /* __MAIN_H*/
