#include "stm8s_conf.h"
#include "ws2812b.h"
#include "clk.h"
#include "timerTick.h"

TIME ledTick;
TIME ledResetTick;
uint8_t ledMode = 0;
int a;
int b;
int c;
void clk_config(void)
{
  CLK_DeInit();
  CLK_HSIPrescalerConfig(CLK_PRESCALER_HSIDIV1);
  CLK->PCKENR1 |= 0x20;
}
INTERRUPT_HANDLER(TIM4_UPD_OVF_IRQHandler, 23)
{
  TIM4_ClearITPendingBit(TIM4_IT_UPDATE);
  TIMER_Inc();
}



void main(void)
{
  uint8_t i;
  uint8_t mode = 0;
  uint8_t delayCnt = 0;
  clk_config();
  GPIO_Init(GPIOA, GPIO_PIN_3, GPIO_MODE_OUT_PP_LOW_FAST);
  TIMER_Init();
  enableInterrupts();
  WS2812_Reset();
  WS2812_SendArray();
  while (1)
  {
    switch (mode) {
    case 0:
      if (!TIMER_CheckTimeMS(&ledTick, 15))
      {
        if (++delayCnt >= 10)
        {
          delayCnt = 0;
          mode++;
          WS2812_Reset();
        }
        ledMode = ~ledMode;
        for (i = 0; i < NB_LEDS; i++)
        {
          if (i % 2 == 0) {
            if (ledMode)
              WS2812_send_data(i, GUI_BLUE);
            else
              WS2812_send_data(i, GUI_ORANGE);
          }
          else {
            if (ledMode)
              WS2812_send_data(i, GUI_ORANGE);
            else
              WS2812_send_data(i, GUI_BLUE);
          }
        }
      }
      WS2812_SendArray();
      break;
    case 1:
      if (!TIMER_CheckTimeMS(&ledTick, 15))
      {
        if (++delayCnt >= 10)
        {
          delayCnt = 0;
          mode++;
          WS2812_Reset();
        }
        ledMode = ~ledMode;
        for (i = 0; i < NB_LEDS; i++)
        {
          if (i % 10 < 5) {
            if (ledMode)
              WS2812_send_data(i, GUI_BLUE);
            else
              WS2812_send_data(i, GUI_ORANGE);
          }
          else {
            if (ledMode)
              WS2812_send_data(i, GUI_ORANGE);
            else
              WS2812_send_data(i, GUI_BLUE);
          }
        }
      }
      WS2812_SendArray();
      break;
    case 2:
      if (!TIMER_CheckTimeMS(&ledTick, 15))
      {
        if (++delayCnt >= 10)
        {
          delayCnt = 0;
          mode = 0;
          WS2812_Reset();
        }
        ledMode = ~ledMode;
        for (i = 0; i < NB_LEDS; i++)
        {
          if (ledMode)
            WS2812_send_data(i, GUI_BLUE);
          else
            WS2812_send_data(i, GUI_ORANGE);
        }
      }

      WS2812_SendArray();
      break;
    }
  }
}
